import { ClerkProvider, SignedIn, SignedOut, UserButton } from '@clerk/nextjs';
import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Premium Finance - Australian Financial Tracker',
  description: 'Track your income, expenses, super, trading, and budgets. Built for Australians.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body>
          <SignedOut>
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 to-pink-50">
              <div className="text-center">
                <h1 className="text-5xl font-bold mb-6">✨ Premium Finance</h1>
                <p className="text-xl text-gray-600 mb-8">Sign in to access your financial dashboard</p>
              </div>
            </div>
          </SignedOut>
          
          <SignedIn>
            <div className="min-h-screen">
              <div className="fixed top-4 right-4 z-50">
                <UserButton afterSignOutUrl="/" />
              </div>
              {children}
            </div>
          </SignedIn>
        </body>
      </html>
    </ClerkProvider>
  );
}

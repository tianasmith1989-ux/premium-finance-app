'use client';

import { useState, useEffect } from 'react';
import { useUser } from '@clerk/nextjs';

export default function FinanceApp() {
  const { user, isLoaded } = useUser();
  
  // All state management
  const [activeTab, setActiveTab] = useState("dashboard");
  const [transactions, setTransactions] = useState([]);
  const [savings, setSavings] = useState([]);
  const [debts, setDebts] = useState([]);
  const [goals, setGoals] = useState([]);
  const [budgets, setBudgets] = useState({
    "Housing": 2000,
    "Transportation": 500,
    "Food": 600,
    "Entertainment": 300,
    "Shopping": 400,
    "Healthcare": 200,
    "Other": 500
  });
  const [household, setHousehold] = useState({
    type: "single",
    adults: 1,
    children: 0,
    names: [""]
  });
  const [trading, setTrading] = useState({
    isTrader: false,
    monthlyProfit: 0,
    monthlyLoss: 0,
    subscriptions: [],
    brokerFees: 0,
    dataSoftware: [],
    notes: ""
  });
  const [newMortgage, setNewMortgage] = useState({
    propertyValue: "",
    loanBalance: "",
    interestRate: "",
    monthlyPayment: ""
  });
  const [hasMortgage, setHasMortgage] = useState(false);
  const [showHouseholdSettings, setShowHouseholdSettings] = useState(false);
  const [goalViewFrequency, setGoalViewFrequency] = useState("monthly");
  
  // Form states
  const [newTransaction, setNewTransaction] = useState({
    name: "", amount: "", type: "expense", category: "Other", frequency: "monthly"
  });
  const [newSaving, setNewSaving] = useState({
    name: "", balance: "", type: "Savings Account"
  });
  const [newDebt, setNewDebt] = useState({
    name: "", balance: "", interestRate: "", minPayment: ""
  });
  const [newGoal, setNewGoal] = useState({
    name: "", target: "", saved: "", deadlineMonths: ""
  });
  const [newTradingSub, setNewTradingSub] = useState({
    name: "", cost: "", frequency: "monthly", type: "subscription"
  });
  const [newBudgetCategory, setNewBudgetCategory] = useState({
    name: "", amount: ""
  });
  const [editingBudget, setEditingBudget] = useState(null);
  const [tempBudgetValue, setTempBudgetValue] = useState("");

  // Load user data from database
  useEffect(() => {
    if (user) {
      loadUserData();
    }
  }, [user]);

  // Save data to database whenever it changes
  useEffect(() => {
    if (user) {
      saveUserData();
    }
  }, [transactions, savings, debts, goals, budgets, household, trading, newMortgage, hasMortgage]);

  const loadUserData = async () => {
    try {
      const response = await fetch('/api/user-data');
      if (response.ok) {
        const data = await response.json();
        if (data.transactions) setTransactions(data.transactions);
        if (data.savings) setSavings(data.savings);
        if (data.debts) setDebts(data.debts);
        if (data.goals) setGoals(data.goals);
        if (data.budgets) setBudgets(data.budgets);
        if (data.household) setHousehold(data.household);
        if (data.trading) setTrading(data.trading);
        if (data.mortgage) {
          setNewMortgage(data.mortgage);
          setHasMortgage(true);
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const saveUserData = async () => {
    try {
      await fetch('/api/user-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactions,
          savings,
          debts,
          goals,
          budgets,
          household,
          trading,
          mortgage: hasMortgage ? newMortgage : null
        })
      });
    } catch (error) {
      console.error('Error saving data:', error);
    }
  };

  const categories = Object.keys(budgets);
  const frequencyToPerYear = { weekly: 52, fortnightly: 26, monthly: 12, yearly: 1 };

  const convertToMonthly = (amount, frequency) => {
    const perYear = frequencyToPerYear[frequency] || 12;
    return amount * (perYear / 12);
  };

  const convertMonthlyToFrequency = (monthlyAmount, targetFrequency) => {
    const targetPerYear = frequencyToPerYear[targetFrequency] || 12;
    return monthlyAmount * (12 / targetPerYear);
  };

  // Calculations
  const mortgageDebt = hasMortgage ? parseFloat(newMortgage.loanBalance) || 0 : 0;
  const mortgageAsset = hasMortgage ? parseFloat(newMortgage.propertyValue) || 0 : 0;
  const mortgagePayment = hasMortgage ? parseFloat(newMortgage.monthlyPayment) || 0 : 0;

  const tradingNetIncome = trading.isTrader ? (trading.monthlyProfit - trading.monthlyLoss) : 0;
  const tradingSubscriptionCosts = trading.isTrader 
    ? [...trading.subscriptions, ...trading.dataSoftware].reduce((sum, sub) => 
        sum + convertToMonthly(parseFloat(sub.cost) || 0, sub.frequency || "monthly"), 0
      ) + (trading.brokerFees || 0)
    : 0;

  const totalIncome = transactions
    .filter(t => t.type === "income")
    .reduce((sum, t) => sum + convertToMonthly(t.amount, t.frequency || "monthly"), 0) + tradingNetIncome;
  
  const totalExpenses = transactions
    .filter(t => t.type === "expense")
    .reduce((sum, t) => sum + convertToMonthly(t.amount, t.frequency || "monthly"), 0) + mortgagePayment + tradingSubscriptionCosts;
  
  const remainingCash = totalIncome - totalExpenses;
  const totalSavings = savings.reduce((sum, s) => sum + s.balance, 0) + mortgageAsset;
  const totalDebt = debts.reduce((sum, d) => sum + d.balance, 0) + mortgageDebt;
  const netWorth = totalSavings - totalDebt;

  const categorySpending = categories.reduce((acc, cat) => {
    acc[cat] = transactions
      .filter(t => t.type === "expense" && t.category === cat)
      .reduce((sum, t) => sum + convertToMonthly(t.amount, t.frequency || "monthly"), 0);
    return acc;
  }, {});

  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 to-pink-50">
        <div className="text-center">
          <div className="text-6xl mb-4">⏳</div>
          <p className="text-xl text-gray-600">Loading your finances...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 to-pink-50">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Please sign in</h1>
          <p className="text-gray-600">You need to be signed in to access Premium Finance</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-pink-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-xl">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex justify-between items-center flex-wrap gap-4">
            <div>
              <h1 className="text-4xl font-bold">✨ Premium Finance</h1>
              <p className="text-indigo-100 mt-1">
                Welcome, {user.firstName || user.emailAddresses[0].emailAddress}!
                {household.type === "couple" && " • Couple"}
                {household.type === "family" && ` • Family (${household.adults} adults, ${household.children} children)`}
                {trading.isTrader && " • Trader"}
              </p>
            </div>
            <div className="flex gap-3">
              {!trading.isTrader && (
                <button
                  onClick={() => setTrading({...trading, isTrader: true})}
                  className="px-4 py-2 bg-gradient-to-r from-sky-500 to-sky-600 rounded-lg font-medium hover:from-sky-600 hover:to-sky-700 transition"
                >
                  📈 Enable Trading
                </button>
              )}
              <button
                onClick={() => setShowHouseholdSettings(!showHouseholdSettings)}
                className="px-4 py-2 bg-white/20 border-2 border-white/30 rounded-lg font-medium hover:bg-white/30 transition"
              >
                ⚙️ Household
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mt-6 overflow-x-auto pb-2">
            {[
              { id: "dashboard", label: "📊 Dashboard" },
              { id: "savings", label: "💰 Savings" },
              trading.isTrader && { id: "trading", label: "📈 Trading" },
              { id: "budgets", label: "💵 Budgets" },
              { id: "forecast", label: "📊 Forecast" }
            ].filter(Boolean).map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-5 py-2.5 rounded-lg font-medium transition whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-white text-indigo-600'
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4">
              Total Net Worth: <span className="text-green-600">${netWorth.toFixed(2)}</span>
            </h2>
            <div className="text-xl text-gray-600 space-y-2">
              <p>Income: ${totalIncome.toFixed(2)}/mo • Expenses: ${totalExpenses.toFixed(2)}/mo • Saving: ${remainingCash.toFixed(2)}/mo</p>
              <p className="text-2xl mt-4">
                Financial Health: {remainingCash >= 0 ? '🌟 ' : '⚠️ '}
                {remainingCash >= totalIncome * 0.2 ? 'Excellent' : remainingCash >= 0 ? 'Good' : 'Needs Attention'}
              </p>
            </div>

            <div className="mt-8 p-6 bg-blue-50 rounded-xl text-left">
              <h3 className="font-bold text-lg mb-3">📝 Quick Tips:</h3>
              <ul className="space-y-2 text-gray-700">
                <li>• All your data syncs across devices</li>
                <li>• Use the tabs above to track different aspects of your finances</li>
                <li>• Your data is encrypted and secure</li>
                <li>• Changes save automatically</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
